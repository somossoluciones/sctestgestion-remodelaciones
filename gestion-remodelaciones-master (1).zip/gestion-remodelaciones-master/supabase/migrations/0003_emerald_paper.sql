/*
  # Add write policies for bases and services

  1. Changes
    - Add INSERT, UPDATE, and DELETE policies for bases table
    - Add INSERT, UPDATE, and DELETE policies for services table

  2. Security
    - Only authenticated users can modify bases and services
*/

-- Add write policies for bases
CREATE POLICY "Allow authenticated insert bases" ON bases
  FOR INSERT TO authenticated WITH CHECK (true);

CREATE POLICY "Allow authenticated update bases" ON bases
  FOR UPDATE TO authenticated USING (true);

CREATE POLICY "Allow authenticated delete bases" ON bases
  FOR DELETE TO authenticated USING (true);

-- Add write policies for services
CREATE POLICY "Allow authenticated insert services" ON services
  FOR INSERT TO authenticated WITH CHECK (true);

CREATE POLICY "Allow authenticated update services" ON services
  FOR UPDATE TO authenticated USING (true);

CREATE POLICY "Allow authenticated delete services" ON services
  FOR DELETE TO authenticated USING (true);