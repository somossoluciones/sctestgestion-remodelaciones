/*
  # Reset and recreate database schema

  1. Changes
    - Drop and recreate all tables with proper relationships
    - Enable RLS and create policies
    - Add pgcrypto extension

  2. Tables
    - bases
    - services
    - properties
    - units
    - service_assignments

  3. Security
    - Enable RLS on all tables
    - Create policies for authenticated users
*/

-- Drop existing tables if they exist
DROP TABLE IF EXISTS service_assignments;
DROP TABLE IF EXISTS units;
DROP TABLE IF EXISTS properties;
DROP TABLE IF EXISTS services;
DROP TABLE IF EXISTS bases;

-- Enable pgcrypto for UUID generation
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- Bases table
CREATE TABLE bases (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  base_price DECIMAL(10,2) NOT NULL,
  status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'inactive')),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Services table
CREATE TABLE services (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  unit_price DECIMAL(10,2) NOT NULL,
  category TEXT NOT NULL,
  unit TEXT NOT NULL,
  multiplier DECIMAL(10,2) NOT NULL DEFAULT 1.0,
  status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'inactive')),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Properties table
CREATE TABLE properties (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  complex_name TEXT NOT NULL,
  address TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'in_progress', 'completed')),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Units table
CREATE TABLE units (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  property_id UUID NOT NULL REFERENCES properties(id),
  base_id UUID NOT NULL REFERENCES bases(id),
  total_cost DECIMAL(10,2) NOT NULL DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'in_progress', 'completed')),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Service assignments table
CREATE TABLE service_assignments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  unit_id UUID NOT NULL REFERENCES units(id),
  service_id UUID NOT NULL REFERENCES services(id),
  quantity DECIMAL(10,2) NOT NULL DEFAULT 1,
  total DECIMAL(10,2) NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE bases ENABLE ROW LEVEL SECURITY;
ALTER TABLE services ENABLE ROW LEVEL SECURITY;
ALTER TABLE properties ENABLE ROW LEVEL SECURITY;
ALTER TABLE units ENABLE ROW LEVEL SECURITY;
ALTER TABLE service_assignments ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Allow authenticated read bases" ON bases
  FOR SELECT TO authenticated USING (true);

CREATE POLICY "Allow authenticated read services" ON services
  FOR SELECT TO authenticated USING (true);

CREATE POLICY "Allow authenticated CRUD on properties" ON properties
  FOR ALL TO authenticated USING (true);

CREATE POLICY "Allow authenticated CRUD on units" ON units
  FOR ALL TO authenticated USING (true);

CREATE POLICY "Allow authenticated CRUD on service_assignments" ON service_assignments
  FOR ALL TO authenticated USING (true);