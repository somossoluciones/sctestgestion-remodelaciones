-- Create enum for user roles if not exists
do $$ 
begin
    if not exists (select 1 from pg_type where typname = 'user_role') then
        create type user_role as enum ('developer', 'client');
    end if;
end $$;

-- Modify or add role column to auth.users
do $$
begin
    if exists (
        select 1
        from information_schema.columns
        where table_schema = 'auth'
        and table_name = 'users'
        and column_name = 'role'
    ) then
        -- Column exists, alter its type
        alter table auth.users 
        alter column role type user_role using role::text::user_role;
    else
        -- Column doesn't exist, add it
        alter table auth.users 
        add column role user_role default 'client';
    end if;
end $$;

-- Create policy to allow users to read their own role if not exists
do $$
begin
    if not exists (
        select 1
        from pg_policies
        where schemaname = 'auth'
        and tablename = 'users'
        and policyname = 'Users can read own role'
    ) then
        create policy "Users can read own role"
        on auth.users
        for select
        using (auth.uid() = id);
    end if;
end $$;

-- Set developer role for specific email
update auth.users 
set role = 'developer' 
where email = 'creandolasoluciones@gmail.com';
