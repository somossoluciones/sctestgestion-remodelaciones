import { createServerClient } from '@supabase/ssr';
import { cookies } from 'next/headers';
import { NextResponse } from 'next/server';
import { ReadonlyRequestCookies } from "next/dist/server/web/spec-extension/adapters/request-cookies";

export async function GET(request: Request) {
  const requestUrl = new URL(request.url);
  const code = requestUrl.searchParams.get('code');

  if (code) {
    const cookieStore = cookies() as unknown as ReadonlyRequestCookies;
    const supabase = createServerClient(
      process.env.NEXT_PUBLIC_SUPABASE_URL!,
      process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
      {
        cookies: {
          get(name: string) {
            const cookie = cookieStore.get(name);
            return cookie?.value;
          },
          set(name: string, value: string, options: any) {
            // Las cookies se manejan a través del middleware
          },
          remove(name: string, options: any) {
            // Las cookies se manejan a través del middleware
          },
        },
      }
    );

    console.log('Intercambiando código por sesión:', code);
    const { error } = await supabase.auth.exchangeCodeForSession(code);
    if (error) {
      console.error('Error al intercambiar código por sesión:', error);
    }

    // Obtener la sesión actual
    const { data: { session }, error: sessionError } = await supabase.auth.getSession();
    if (sessionError) {
      console.error('Error al obtener la sesión:', sessionError);
    }

    if (session) {
      // Obtener el rol del usuario
      const { data: userData } = await supabase
        .from('auth.users')
        .select('role')
        .eq('id', session.user.id)
        .single();

      // Redirigir basado en el rol
      const role = userData?.role || 'client';
      const redirectPath = 
        role === 'developer' ? '/dashboard/bases' : 
        role === 'authenticated' ? '/dashboard/properties' : 
        '/login';

      return NextResponse.redirect(new URL(redirectPath, request.url));
    }
  }

  // Si algo falla, redirigir al login
  return NextResponse.redirect(new URL('/login', request.url));
}
