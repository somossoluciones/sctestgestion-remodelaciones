import { createServerClient } from '@supabase/ssr';
import { cookies } from 'next/headers';
import { NextResponse } from 'next/server';
import { ReadonlyRequestCookies } from "next/dist/server/web/spec-extension/adapters/request-cookies";

export async function POST(request: Request) {
  const cookieStore = cookies() as unknown as ReadonlyRequestCookies;
  const supabase = createServerClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
    {
      cookies: {
        get(name: string) {
          const cookie = cookieStore.get(name);
          return cookie?.value;
        },
        set(name: string, value: string, options: any) {
          // Las cookies se manejan a través del middleware
        },
        remove(name: string, options: any) {
          // Las cookies se manejan a través del middleware
        },
      },
    }
  );
  
  await supabase.auth.signOut();
  return NextResponse.redirect(new URL('/login', request.url));
}
