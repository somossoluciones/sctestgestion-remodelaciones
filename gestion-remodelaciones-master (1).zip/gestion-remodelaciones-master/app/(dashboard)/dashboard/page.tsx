'use client';

import { useEffect, useState } from 'react';
import { createClient } from 'lib/supabase/client'; // Ajustar la ruta de importación
import { Card, CardContent, CardHeader, CardTitle } from 'components/ui/card';
import { Database, Building2 } from 'lucide-react'; // Eliminar 'Tool' si no está disponible

interface DashboardStats {
  basesCount: number;
  servicesCount: number;
  propertiesCount: number;
}

export default function DashboardPage() {
  const [stats, setStats] = useState<DashboardStats>({
    basesCount: 0,
    servicesCount: 0,
    propertiesCount: 0,
  });

  const supabase = createClient(); // Crear una instancia de supabase

  useEffect(() => {
    async function fetchStats() {
      try {
        const [basesData, servicesData, propertiesData] = await Promise.all([
          supabase.from('bases').select('id', { count: 'exact' }),
          supabase.from('services').select('id', { count: 'exact' }),
          supabase.from('properties').select('id', { count: 'exact' }),
        ]);
        setStats({
          basesCount: basesData.count || 0,
          servicesCount: servicesData.count || 0,
          propertiesCount: propertiesData.count || 0,
        });
      } catch (error) {
        console.error('Error fetching stats:', error);
      }
    }

    fetchStats();
  }, []);

  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold" aria-live="polite">Dashboard Overview</h1>

      <div className="grid gap-4 md:grid-cols-3">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Bases</CardTitle>
            <Database className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.basesCount}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Services</CardTitle>
            <Building2 className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.servicesCount}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Properties</CardTitle>
            <Building2 className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.propertiesCount}</div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
