export default function BasesPage() {
  return (
    <div className="container mx-auto p-6">
      <h1 className="text-2xl font-bold mb-6">Gestión de Bases</h1>
      <div className="grid gap-4">
        <div className="p-4 border rounded-lg bg-white shadow">
          <p className="text-gray-600">Aquí podrás gestionar las bases de precios para las renovaciones.</p>
        </div>
      </div>
    </div>
  );
}
