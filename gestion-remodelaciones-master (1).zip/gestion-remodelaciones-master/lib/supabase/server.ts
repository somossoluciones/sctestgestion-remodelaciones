import { createServerClient } from "@supabase/ssr";
import { cookies } from "next/headers";
import { ReadonlyRequestCookies } from "next/dist/server/web/spec-extension/adapters/request-cookies";

export const createClient = () => {
  const cookieStore = cookies() as unknown as ReadonlyRequestCookies;

  return createServerClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
    {
      cookies: {
        get(name: string) {
          const cookie = cookieStore.get(name);
          return cookie?.value;
        },
        set(name: string, value: string, options: any) {
          // En Next.js 15, las cookies son de solo lectura en Server Components
          // Las cookies se manejan a través del middleware
        },
        remove(name: string, options: any) {
          // En Next.js 15, las cookies son de solo lectura en Server Components
          // Las cookies se manejan a través del middleware
        },
      },
    }
  );
};
