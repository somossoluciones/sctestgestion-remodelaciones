import { createServerClient, type CookieOptions } from "@supabase/ssr";
import { NextResponse, type NextRequest } from "next/server";

export async function middleware(request: NextRequest) {
  let response = NextResponse.next({
    request: {
      headers: request.headers,
    },
  });

  const supabase = createServerClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
    {
      cookies: {
        get(name: string) {
          return request.cookies.get(name)?.value;
        },
        set(name: string, value: string, options: CookieOptions) {
          // Configuramos las cookies tanto en la request como en la response
          request.cookies.set({
            name,
            value,
            ...options,
          });
          response = NextResponse.next({
            request: {
              headers: request.headers,
            },
          });
          response.cookies.set({
            name,
            value,
            ...options,
          });
        },
        remove(name: string, options: CookieOptions) {
          request.cookies.delete(name);
          response = NextResponse.next({
            request: {
              headers: request.headers,
            },
          });
          response.cookies.delete(name);
        },
      },
    }
  );

  try {
    // Renovar la sesión si existe
    const { data: { session }, error } = await supabase.auth.getSession();

    // Manejo de rutas protegidas
    if (request.nextUrl.pathname.startsWith('/dashboard')) {
      if (!session) {
        // Redirigir a login si no hay sesión
        return NextResponse.redirect(new URL('/login', request.url));
      }
      
      // Opcional: Verificar rol para rutas específicas
      if (request.nextUrl.pathname.startsWith('/dashboard/admin')) {
        const { data: userData } = await supabase
          .from('profiles')
          .select('role')
          .eq('id', session.user.id)
          .single();

        if (userData?.role !== 'admin') {
          // Redirigir si no tiene permisos
          return NextResponse.redirect(new URL('/dashboard', request.url));
        }
      }
    }

    return response;

  } catch (error) {
    console.error('Error in middleware:', error);
    // En caso de error, redirigir a login
    return NextResponse.redirect(new URL('/login', request.url));
  }
}

// Configurar las rutas que deben ser manejadas por el middleware
export const config = {
  matcher: [
    /*
     * Match all request paths except:
     * - _next/static (static files)
     * - _next/image (image optimization files)
     * - favicon.ico (favicon file)
     * - public /images folder
     * - api routes
     */
    '/((?!_next/static|_next/image|favicon.ico|public/images|api).*)',
  ],
};