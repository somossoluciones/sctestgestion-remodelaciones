# Prompt: Sistema de Gestión de Renovaciones MRQZ REMODELING LLC

## Contexto del Proyecto
Desarrollar un sistema de gestión de renovaciones de propiedades para MRQZ REMODELING LLC, una empresa especializada en renovaciones y mejoras de propiedades residenciales, multifamiliares y complejos de apartamentos en Estados Unidos.

## Stack Tecnológico Requerido
- Frontend: Next.js 14+ con App Router
- Lenguaje: TypeScript
- UI Components: shadcn/ui
- Formularios: react-hook-form con Zod
- Base de Datos y Autenticación: Supabase
- State Management: Zustand
- API: tRPC (opcional para type-safety end-to-end)

## Arquitectura Propuesta

### 1. Arquitectura de Carpetas
```
src/
├── app/
│   ├── (auth)/
│   │   ├── login/
│   │   └── register/
│   ├── (dashboard)/
│   │   ├── bases/
│   │   ├── services/
│   │   └── properties/
│   └── layout.tsx
├── components/
│   ├── ui/
│   ├── forms/
│   │   ├── base-form.tsx
│   │   ├── service-form.tsx
│   │   └── property-form.tsx
│   └── shared/
├── lib/
│   ├── supabase/
│   ├── utils/
│   └── constants/
├── store/
│   └── slices/
└── types/
```

### 2. Patrones de Diseño Recomendados

1. **Repository Pattern**
   - Implementar una capa de abstracción para operaciones de base de datos
   - Facilitar el testing y mantenimiento

2. **Feature-First Architecture**
   - Organizar código por características funcionales
   - Mantener componentes y lógica relacionada junta

3. **Command Pattern** para operaciones CRUD
   - Estandarizar operaciones de datos
   - Facilitar logging y validación

4. **Factory Pattern** para formularios dinámicos
   - Crear formularios basados en configuración
   - Reutilizar lógica común

### 3. Modelos de Datos

```typescript
// Definiciones de tipos base
interface Base {
  id: string
  name: string
  basePrice: number
  status: 'active' | 'inactive'
  createdAt: Date
  updatedAt: Date
}

interface Service {
  id: string
  name: string
  unitPrice: number
  category: string
  unit: string
  multiplier: number
  status: 'active' | 'inactive'
}

interface Property {
  id: string
  complexName: string
  address: string
  units: Unit[]
  status: 'active' | 'in_progress' | 'completed'
}

interface Unit {
  id: string
  propertyId: string
  baseId: string
  services: ServiceAssignment[]
  totalCost: number
  status: 'pending' | 'in_progress' | 'completed'
}

interface ServiceAssignment {
  id: string
  unitId: string
  serviceId: string
  quantity: number
  total: number
}
```

### 4. Features Principales

1. **Sistema de Autenticación**
   - Roles: Admin, Manager, Contractor
   - Permisos basados en roles
   - Sesiones persistentes

2. **Gestión de Bases**
   - CRUD completo
   - Historial de cambios
   - Validación de precios

3. **Catálogo de Servicios**
   - Categorización
   - Precios dinámicos
   - Unidades de medida

4. **Gestión de Propiedades**
   - Jerarquía de unidades
   - Estado de renovación
   - Cálculos automáticos

5. **Dashboard Analítico**
   - KPIs principales
   - Gráficos de progreso
   - Reportes exportables

### 5. Mejores Prácticas

1. **Seguridad**
   - Implementar middleware de autenticación
   - Validación de datos con Zod
   - Rate limiting en APIs
   - Sanitización de inputs

2. **Performance**
   - Implementar ISR para páginas estáticas
   - Lazy loading de componentes pesados
   - Optimización de imágenes
   - Caching estratégico

3. **UX/UI**
   - Diseño responsive
   - Feedback inmediato
   - Manejo de errores amigable
   - Loading states

4. **Code Quality**
   - TypeScript strict mode
   - ESLint + Prettier
   - Husky pre-commit hooks
   - Jest para testing

### 6. Requerimientos No Funcionales

1. **Escalabilidad**
   - Arquitectura modular
   - Código reutilizable
   - Optimización de queries

2. **Mantenibilidad**
   - Documentación clara
   - Convenciones de código
   - Logging comprensivo

3. **Rendimiento**
   - Tiempo de carga < 3s
   - FCP < 1.5s
   - TTI < 3.5s

### 7. Entregables Esperados

1. Código fuente completo en GitHub
2. Documentación técnica
3. Scripts de migración de DB
4. Manual de usuario
5. Pruebas unitarias y e2e
6. Docker setup

### 8. Componentes Reutilizables Sugeridos

1. **DataTable**
```typescript
interface DataTableProps<T> {
  data: T[]
  columns: ColumnDef<T>[]
  pagination?: PaginationOptions
  onRowClick?: (row: T) => void
  actions?: TableAction[]
}
```

2. **FormBuilder**
```typescript
interface FormBuilderProps {
  schema: ZodSchema
  fields: FormField[]
  onSubmit: (data: any) => Promise<void>
  defaultValues?: Record<string, any>
}
```

3. **StatusBadge**
```typescript
interface StatusBadgeProps {
  status: 'active' | 'inactive' | 'pending' | 'completed'
  size?: 'sm' | 'md' | 'lg'
}
```

### 9. Hooks Personalizados Recomendados

1. **useAuth**
```typescript
const useAuth = () => {
  // Gestión de autenticación
  return {
    user,
    login,
    logout,
    isLoading,
    error
  }
}
```

2. **useForm**
```typescript
const useFormWithValidation = <T extends ZodSchema>(schema: T) => {
  // Integración react-hook-form + zod
  return {
    register,
    handleSubmit,
    errors,
    isValid
  }
}
```

3. **useQueryWithCache**
```typescript
const useQueryWithCache = <T>(key: string, fetcher: () => Promise<T>) => {
  // Manejo de cache y revalidación
  return {
    data,
    isLoading,
    error,
    refetch
  }
}
```

