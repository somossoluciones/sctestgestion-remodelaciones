import { ColumnDef } from '@tanstack/react-table';
import { Button } from '@/components/ui/button';
import { ArrowUpDown } from 'lucide-react';

export function createSortableHeader(label: string, accessorKey: string) {
  return (
    <Button variant="ghost" className="p-0 hover:bg-transparent">
      <span>{label}</span>
      <ArrowUpDown className="ml-2 h-4 w-4" />
    </Button>
  );
}