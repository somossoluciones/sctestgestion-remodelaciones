export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export interface Database {
  public: {
    Tables: {
      bases: {
        Row: {
          id: string
          name: string
          base_price: number
          status: 'active' | 'inactive'
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          name: string
          base_price: number
          status?: 'active' | 'inactive'
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          name?: string
          base_price?: number
          status?: 'active' | 'inactive'
          updated_at?: string
        }
      }
      services: {
        Row: {
          id: string
          name: string
          unit_price: number
          category: string
          unit: string
          multiplier: number
          status: 'active' | 'inactive'
          created_at: string
        }
        Insert: {
          id?: string
          name: string
          unit_price: number
          category: string
          unit: string
          multiplier?: number
          status?: 'active' | 'inactive'
          created_at?: string
        }
        Update: {
          name?: string
          unit_price?: number
          category?: string
          unit?: string
          multiplier?: number
          status?: 'active' | 'inactive'
        }
      }
      properties: {
        Row: {
          id: string
          complex_name: string
          address: string
          status: 'active' | 'in_progress' | 'completed'
          created_at: string
        }
        Insert: {
          id?: string
          complex_name: string
          address: string
          status?: 'active' | 'in_progress' | 'completed'
          created_at?: string
        }
        Update: {
          complex_name?: string
          address?: string
          status?: 'active' | 'in_progress' | 'completed'
        }
      }
    }
  }
}