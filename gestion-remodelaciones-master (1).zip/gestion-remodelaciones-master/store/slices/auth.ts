import { create } from 'zustand';
import { createClient } from '@/lib/supabase/client';
import { User } from '@supabase/supabase-js';

interface AuthState {
  user: User | null;
  isLoading: boolean;
  error: Error | null;
  signUp: (email: string, password: string) => Promise<void>;
  signIn: (email: string, password: string) => Promise<void>;
  signOut: () => Promise<void>;
}

const supabase = createClient();

export const useAuthStore = create<AuthState>((set) => ({
  user: null,
  isLoading: true,
  error: null,

  signUp: async (email: string, password: string) => {
    try {
      set({ isLoading: true, error: null });
      const { data: { session }, error } = await supabase.auth.signUp({
        email,
        password
      });
      if (error) throw error;
      set({ user: session?.user ?? null, isLoading: false });
      if (!session) {
        set({ 
          error: new Error('Por favor, revisa tu correo electrónico para confirmar tu cuenta'), 
          isLoading: false 
        });
      }
    } catch (error) {
      set({ 
        error: new Error('Error al crear la cuenta. Por favor, intenta nuevamente.'), 
        isLoading: false 
      });
    }
  },

  signIn: async (email: string, password: string) => {
    try {
      set({ isLoading: true, error: null });
      const { data: { session }, error } = await supabase.auth.signInWithPassword({
        email,
        password,
      });
      if (error) throw error;
      set({ user: session?.user ?? null, isLoading: false });
    } catch (error) {
      const e = error as Error;
      if (e.message === 'Email not confirmed') {
        set({ 
          error: new Error('Por favor, revisa tu correo electrónico para confirmar tu cuenta'), 
          isLoading: false 
        });
      } else {
        set({ 
          error: new Error('Error al iniciar sesión. Por favor, verifica tus credenciales.'), 
          isLoading: false 
        });
      }
    }
  },

  signOut: async () => {
    try {
      set({ isLoading: true, error: null });
      const { error } = await supabase.auth.signOut();
      if (error) throw error;
      set({ user: null, isLoading: false });
    } catch (error) {
      set({ error: error as Error, isLoading: false });
    }
  },
}));
